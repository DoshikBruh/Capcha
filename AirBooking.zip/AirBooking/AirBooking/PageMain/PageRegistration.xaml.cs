﻿using AirBooking.AppServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLib;

namespace AirBooking.PageMain
{
    /// <summary>
    /// Interaction logic for PageRegistration.xaml
    /// </summary>
    public partial class PageRegistration : Page
    {
        public PageRegistration()
        {
            InitializeComponent();
            String allowchar;

            allowchar = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";

            allowchar += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,y,z";

            allowchar += "1,2,3,4,5,6,7,8,9,0";

            allowchar += "!,@,#,№,*,$";

            char[] a = { ',' };

            String[] ar = allowchar.Split(a);

            string pwd = "";

            string temp;

            Random r = new Random();


            for (int i = 0; i < 6; i++)

            {

                temp = ar[(r.Next(0, ar.Length))];



                pwd += temp;

            }


            CapchaBlock.Text = pwd;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        /// <summary>
        /// Кнопка создания пользователя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            if (CapchaBlock.Text == Capcha.Text)
            {
                if (DbConnect.entObj.User.Count(x => x.Login == TxbLogin.Text) > 0)
                {
                    MessageBox.Show("Такой пользователь уже есть",
                                    "Уведомление",
                                    MessageBoxButton.OK,
                                    MessageBoxImage.Information);
                    return;
                }
                else
                {
                    try
                    {
                        User userObj = new User()
                        {
                            Login = TxbLogin.Text,
                            Password = PsbPassword.Password,
                            IdRole = 1
                        };

                        DbConnect.entObj.User.Add(userObj);
                        DbConnect.entObj.SaveChanges();

                        MessageBox.Show("Пользователь создан",
                                       "Уведомление",
                                       MessageBoxButton.OK,
                                       MessageBoxImage.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка работы приложения: " + ex.Message.ToString(),
                                       "Критический сбой работы приложения",
                                       MessageBoxButton.OK,
                                       MessageBoxImage.Warning);
                    }
                }
            }
            else 
            {
                MessageBox.Show("Неправильно заполненная капча",
                                "Незаполненное поле",
                                MessageBoxButton.OK,
                                MessageBoxImage.Warning);
            }
        }

        /// <summary>
        /// Сравнение паролей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PsbPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (TxbPassword.Text == PsbPassword.Password)
            {
                BtnCreate.IsEnabled = true;
                PsbPassword.Background = Brushes.LightBlue;
                PsbPassword.BorderBrush = Brushes.Blue;
                
            }
            else
            {
                BtnCreate.IsEnabled = false;
                PsbPassword.Background = Brushes.LightCoral;
                PsbPassword.BorderBrush = Brushes.Red;
                
            }

        }
        private void Capcha_CapchaChanged(object sender, RoutedEventArgs e)
        {
            if (CapchaBlock.Text == Capcha.Text)
            {
                BtnCreate.IsEnabled = true;
                
                Capcha.Background = Brushes.LightBlue;
                Capcha.BorderBrush = Brushes.Blue;
            }
            else
            {
                BtnCreate.IsEnabled = false;
                Capcha.Background = Brushes.LightCoral;
                Capcha.BorderBrush = Brushes.Red;

            }

        }

    }
}
