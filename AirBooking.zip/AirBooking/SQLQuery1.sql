CREATE TABLE role (
id int  NOT NULL,
name NVARCHAR (25) NOT NULL
)

CREATE TABLE users (
id int NOT NULL,
name NVARCHAR (25) NOT NULL,
password VARCHAR (10)  NOT NULL,
idrole int NOT NULL
)